package com.habitoapp.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.habitoapp.data.Habit
import com.habitoapp.viewmodel.HabitViewModel

@Composable
fun HabitListScreen(viewModel: HabitViewModel, onAddClick: () -> Unit) {
    val habits by viewModel.habits.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Hábito+") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddClick) {
                Text("+")
            }
        }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            habits.forEach { habit ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleHabit(habit) }
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(habit.name)
                    Checkbox(
                        checked = habit.isCompleted,
                        onCheckedChange = { viewModel.toggleHabit(habit) }
                    )
                }
            }
        }
    }
}