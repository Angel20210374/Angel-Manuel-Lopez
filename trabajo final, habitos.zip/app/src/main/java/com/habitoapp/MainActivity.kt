package com.habitoapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.habitoapp.data.HabitDatabase
import com.habitoapp.ui.AddHabitScreen
import com.habitoapp.ui.HabitListScreen
import com.habitoapp.viewmodel.HabitViewModel
import com.habitoapp.viewmodel.HabitViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dao = HabitDatabase.getDatabase(this).habitDao()
        val factory = HabitViewModelFactory(dao)
        val viewModel: HabitViewModel = viewModel(factory = factory)

        setContent {
            val navController = rememberNavController()

            NavHost(navController, startDestination = "list") {
                composable("list") {
                    HabitListScreen(viewModel) {
                        navController.navigate("add")
                    }
                }
                composable("add") {
                    AddHabitScreen(viewModel) {
                        navController.popBackStack()
                    }
                }
            }
        }
    }
}