package com.example.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.app.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PersonalData(name = "Emilio")
        }
    }
}

@Composable
private fun PersonalData(name: String) {
    MaterialTheme {
        Column(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.jetpack),
                contentDescription = "Imagen de Jetpack",
                modifier = Modifier.height(200.dp)
            )
            Text(text = "Mi nombre es $name", style = MaterialTheme.typography.headlineLarge)
            Text(text = "Soy Angel")
            Text(text = "Estoy aprendiendo JetPack Compose")
            Spacer(modifier = Modifier.height(16.dp))
            MyListComponent()
        }
    }
}

@Composable
fun MyListComponent() {
    val itemsList = listOf("Elemento 1", "Elemento 2", "Elemento 3", "Elemento 4")
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(itemsList) { item ->
            MyComponent(item)
        }
    }
}

@Composable
private fun MyComponent(text: String) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .background(MaterialTheme.colorScheme.background)
            .padding(8.dp)
            .animateContentSize()
    ) {
        MyImage()
        Column(modifier = Modifier.padding(start = 8.dp)) {
            MyText(text, MaterialTheme.colorScheme.primary, MaterialTheme.typography.headlineMedium)
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                MyText("Texto adicional expandido", MaterialTheme.colorScheme.secondary, MaterialTheme.typography.bodyLarge)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (expanded) "Ver menos" else "Ver más",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .background(Color.LightGray)
                    .padding(4.dp)
                    .clip(CircleShape)
                    .clickable { expanded = !expanded }
            )
        }
    }
}

@Composable
fun MyImage() {
    Image(
        painter = painterResource(R.drawable.nuevologo_png),
        contentDescription = "Este es mi logo",
        modifier = Modifier
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary)
            .size(80.dp)
    )
}

@Composable
fun MyText(text: String, color: Color, style: TextStyle) {
    Text(text, color = color, style = style)
}

@Preview
@Composable
fun PreviewPersonalData() {
    PersonalData(name = "JOSPEL")
}
